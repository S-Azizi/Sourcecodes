Help file to run the project written in Python language, developed using jupyter notebook.
Email for more information and questions: r.salimi@uok.ac.ir
You can install Anaconda and then use Jupyter nootebook to run the implementation file or 
use Google colab. The quick way is to use Google Colab which is described below:
Step of running project:
1.    Enter https://colab.research.google.com in your browser 
2.    Click on the File section and then select the Upload notebook option.
3.    Chose Implementation file.
4.    Click on the Runtime section and then select the Run all option.
5.    Enter number of Tasks.
6.    Enter number of Fog nodes.
7.    Enter number of Cloud nodes.
8.    Finally we can repeat this process to get the results.
 
To use the Jupyter notebook, Do as the following procedure:
1.    Download and install Anaconda3.
2.    Open anaconda and select jupyter notebook and chose your browser to open it.
3.    Click on upload and select Implementation file.
4.    Click on cell section and select the Run all option.
5.    Enter number of Tasks.
6.    Enter number of Fog nodes.
7.    Enter number of Cloud nodes.
8.    Finally we can repeat this process to get the results.
