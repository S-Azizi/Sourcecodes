Instructions for Using the Program with the Shanghai Telecom Dataset:

To utilize the program effectively, you need access to the Shanghai Telecom dataset, which we have consolidated into a single entity from its separate files.

File Descriptions and Commands:

1. **1_Sort_NormalBtsData.ipynb**: This file is used to merge and create the Data (01UniqueBts).csv file. This CSV file contains essential information such as BTS ID, number of users, load, longitude, and latitude for 3006 BTS. Considering that Data (01UniqueBts).csv file has already been created, you don't need to execute this part. (Detailed commands are included within the file)

2. **2_AdjacencyMatrix.ipynb**: This file is designed to generate the proximity matrix for communication among all BTS. Considering that Data (02Adjacency_Matrix).csv file has already been created, you don't need to execute this part.(Programs necessary for this operation are written within the file)

3. **3_Main.ipynb**: The proposed algorithm program is implemented in this file. Detailed guidelines for each section are provided within the relevant file. To execute this program, ensure you have installed all the required packages mentioned in the initial part.

4. **4_Results.ipynb**: This file is used for invoking and executing various methods such as Random clustering, Top-K, and K-Means. Detailed information regarding its usage and functionalities is provided within the file itself.

5. **Algorithm.py**: This file contains algorithms for Random clustering, Top-K, and K-Means.