class BtsData:
    code = int
    userCount = int
    timeUsage = int
    latitude = float
    longitude = float
    def __init__(self):
        self.code = 0
        self.userCount = 0
        self.timeUsage = 0
        self.latitude = 0
        self.longitude = 0
    def __init__(self, code, userCount, timeUsage, latitude, longitude):
        self.code = code
        self.userCount = userCount
        self.timeUsage = timeUsage
        self.latitude = latitude
        self.longitude = longitude
        
    def __str__(self):
        return str(round(self.code)) + "," + str(round(self.userCount)) + "," + str(round(self.timeUsage)) + "," + str(self.latitude) + "," + str(self.longitude)
        
    def __repr__(self):
        return str(round(self.code)) + "," + str(round(self.userCount)) + "," + str(round(self.timeUsage)) + "," + str(self.latitude) + "," + str(self.longitude)
        
        
 
    
    
    
            
class BtS_EServer:
    Bts = int
    Server = int 
    WLoad = int 
    def __init__(self):
        self.Bts = 0 
        self.Server = 0 
        self.WLoad = 0 
    def __init__(self, Bts, Server,WLoad):
        self.Bts = Bts
        self.Server = Server 
        self.WLoad = WLoad 
        
    def __str__(self):
        return str(round(self.Bts)) + "," + str(self.Server)+ "," + str(self.WLoad)
        
    def __repr__(self):
        return str(round(self.Bts)) + "," + str(self.Server)+ "," + str(self.WLoad)
    
#Each Bts Data that connect to server   
class ESDBts:
    code = int
    Server = int
    userCount = int
    worload = int
    distanceToServer = int 
    cluster = int 
    def __init__(self):
        self.code = 0
        self.Server = 0
        self.userCount = 0
        self.worload = 0
        self.distanceToServer = 0 
        self.cluster = 0 
    def __init__(self, code,Server, userCount, worload,distanceToServer,cluster):
        self.code = code
        self.Server = Server
        self.userCount = userCount
        self.worload = worload
        self.distanceToServer = distanceToServer 
        self.cluster = cluster 
        
    def __str__(self):
        return str(self.code) + "," + str(self.Server) + "," + str(self.userCount) + "," + str(self.worload) + "," + str(self.distanceToServer) + "," + str(self.cluster) 
        
    def __repr__(self):
        return str(self.code)  + "," + str(self.Server)+ "," + str(self.userCount) + "," + str(self.worload) + "," + str(self.distanceToServer)+ "," + str(self.cluster)
        
    
class EServerData:
    code = int
    count = int
    listOfBts = [] 
    def __init__(self):
        self.code = 0
        self.count = 0
        self.listOfBts = [] 
    def __init__(self, code,count, EServerDataBts):
        self.code = code
        self.count = count
        list1=[]
        list1.append(EServerDataBts)
        self.listOfBts = list1
        
    def __str__(self):
        return str(self.code) + "," + str(self.count) +','.join(self.listOfBts)
        
    def __repr__(self):
        return str(self.code) + "," +str(self.count)  + ','.join(self.listOfBts)
    
    
    #Each server data  
class Servers: 
    Server = int
    btsCount = int
    TotalUsers = int
    Worload = int
    avgDistance = int 
    def __init__(self): 
        self.Server = 0
        self.btsCount = 0
        self.TotalUsers = 0
        self.Worload = 0 
        self.avgDistance = 0 
    def __init__(self,Server, btsCount, TotalUsers,Worload,avgDistance): 
        self.Server = Server
        self.btsCount = btsCount
        self.TotalUsers = TotalUsers
        self.Worload = Worload 
        self.avgDistance = avgDistance 
        
    def __str__(self):
        return str(self.Server) + "," + str(self.btsCount) + "," + str(self.TotalUsers) + "," + str(self.Worload) + "," + str(self.avgDistance) 
        
    def __repr__(self):
        return str(self.Server) + "," + str(self.btsCount) + "," + str(self.TotalUsers) + "," + str(self.Worload) + "," + str(self.avgDistance) 
        
        
        
        
class EdgeServer(object):
    max_workload = 3000000

    def __init__(self, id, latitude, longitude, base_station_id=None):
        self.id = id
        self.latitude = latitude
        self.longitude = longitude
        self.base_station_id = base_station_id
        self.assigned_base_stations = []
        self.workload = 0

    def __str__(self):
        return 'edge_info'.center(30, '=') + '\n EDGE ID \t----> {0}\n Location \t----> {1}\n BS_No \t\t----> {2}\n BS_list \t----> {3}\n Workload \t----> {4}'.format(
            self.id, (self.latitude, self.longitude), self.base_station_id, [i.id for i in self.assigned_base_stations],
            self.workload)