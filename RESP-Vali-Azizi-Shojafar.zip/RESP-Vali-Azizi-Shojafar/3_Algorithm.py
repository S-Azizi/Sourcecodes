import random 
import pandas as pd  
import numpy as np
import csv

from sklearn.cluster import KMeans



import geopy.distance 


def BTS_Server_Di_Wl(df,df2,serverList ): 
    serverList_ = serverList.copy()  
    serverList_.sort()
    selected_dfM  = df.iloc[:,serverList_]   
    newdf = df2.copy()
    newdf["SCode"]=(selected_dfM.idxmin(axis=1).to_numpy()+1).tolist()
    newdf["Distance"]=selected_dfM.min(axis=1).to_numpy().tolist()
    return newdf   

    df = pd.read_csv('BaseData/Start/Data (01UniqueBts).csv' , names=["id", "users", "wl", "lat", "long"]) 
    dfm = pd.read_csv('BaseData/Start/Data (02Adjacency_Matrix).csv' , header=None) 
    file="ClusterRecGrid" 
    df["cluster"]=1 
    avgWl=(df["wl"].sum()/k)   
    splitT = 1.415   
    SplitDataFrameSimple (df,1,k,avgWl,splitT)
    df["SCode"]=-1
    listsrv =[] 
    print("Start")
    addedServer=[]
    for i,item in df.groupby("cluster"):
        cdf = dfm.filter(items = [x-1 for x in (item["id"]).values.tolist()]  , axis=0)
        scode=-1
        minDW = item["wl"].max()*999999 
        for index,row in cdf.iterrows():
            btsdi=0
            btsdi= np.sum([row2[index]*int(df.loc[(df["id"] == index2+1),"wl"]) for index2,row2 in cdf.iterrows()])
            if btsdi< minDW:
                minDW = btsdi
                scode = index+1   
           
                
        listsrv.append([int(scode),int(item["wl"].sum())])        
                
        addedServer.append(scode)#add bts id as server
        df.loc[(df["cluster"] == i),"SCode"] = scode  
        for index,row in item.iterrows():
            df.loc[(df["id"] == index+1),"Distance"] = float(dfm.loc[scode-1,index])  
     
    print(addedServer)       
    kk=len(set(df["cluster"])) 
    df.drop('cluster', axis=1, inplace=True)
    if IsRedesign==1:
        listsrvDF= pd.DataFrame(listsrv,  columns = ['SCode','wl'] ) 
        for _,b in df.iterrows():   
            bcwl= int(listsrvDF[listsrvDF["SCode"] == int(b[5])]["wl"]) # بارکاری کلاستری که ایستگاه در آن قرار دارد
            new_Cluster_id=b[5] 
            for p,c in listsrvDF.iterrows()  : 
                if int(c[0])!=int(b[5])    : #عدم بررسی کلاستر فعلی ایستگاه پایه
                    cwl= int(listsrvDF[listsrvDF["SCode"] == c[0]]["wl"]) #    بارکاری کلاستر سرور مورد بررسی
                    if cwl<(bcwl+treshHol*avgWl) : #b[2] میتونه با همراه بارکاری جدید مقایسه یشه
                        ndis=dfm.iloc[int(b[0])-1][int(c[0])-1]#فاصله ایستگاه تا سرور کلاستر جدید
                        if ndis < b[6]:
                                    #if b[0]==545 and b[5]==886 and c[0]==819:
                                    #    print(b[0],b[5],b[6],c[0],dfm.iloc[int(b[0])-1][int(c[0])-1],bcwl,cwl)
                            df.loc[df["id"] == b[0],"SCode"]=c[0]#تغییر کلاستر ایستگاه
                            df.loc[df["id"] == b[0],"Distance"]=ndis# تغییر فاصله تا سرور
                            new_Cluster_id=c[0]
                            b[5]=c[0]
                            b[6]=ndis
            listsrvDF[listsrvDF["SCode"] == b[5]]["wl"] = int(listsrvDF[listsrvDF["SCode"] == b[5]]["wl"])- int(b[2])                 
            listsrvDF[listsrvDF["SCode"] == new_Cluster_id]["wl"] = int(listsrvDF[listsrvDF["SCode"] == new_Cluster_id]["wl"])+ int(b[2]) 
            
    
    df2=df 
    df.rename( columns={"id":'BCode', "users":'TUsers', "wl":'WLoad', "lat":'Lat', "long":'Long', 'SCode':'SCode','Distance':'Distance'}, inplace=True)     
    df.to_csv ('BaseData/Data ('+file+'_List).csv', index=None, header = True)
    pd.DataFrame(addedServer,  columns = ['server']  ).to_csv ('BaseData/Data (Servers_List1).csv', index=None, header = False)
    return kk,df2 
################################################################################################################
################################################################################################################
def k_Means(k,file,totalBTS):
    df = pd.read_csv('BaseData/Start/Data (01UniqueBts)-'+str(totalBTS)+'.csv' , names=["id", "users", "wl", "lat", "long"])
    X=df.loc[:,["id", "users", "wl", "lat", "long"]]
    kmeans = KMeans(n_clusters = k, init ='k-means++') 
    X['id2'] = kmeans.fit_predict(X[X.columns[3:5]])
    centers = kmeans.cluster_centers_ 
    labels = kmeans.predict(X[X.columns[3:5]])  
    df=pd.DataFrame(X)
    df.to_csv ('BaseData/Data ('+file+').csv', index=None, header = True)
    centers = kmeans.cluster_centers_
    result = list()
    for i in labels:
        if i not in result:
            result.append(i)
    
    Y=X.to_numpy().tolist() 
    List=[]
    newlist=[] 
    closest_pt_idx = []
    for iclust in range(kmeans.n_clusters): 
        cluster_pts_indices = np.where(kmeans.labels_ == iclust)[0]
        cluster_cen = kmeans.cluster_centers_[iclust]
        vv= [round(geopy.distance.geodesic([Y[idx][3],Y[idx][4]], [cluster_cen[0],cluster_cen[1]]).m) for idx in cluster_pts_indices]
        min_idx = np.argmin(vv)
        newlist.append([iclust,cluster_pts_indices[min_idx]+1,vv[min_idx]])
        cord1 = Y[cluster_pts_indices[min_idx]][3:5]
        for i in range(len(Y)):
            if Y[i][5] == iclust:
                c=Y[i]
                ds=round(geopy.distance.geodesic([c[3],c[4]], cord1).m)
                List.append([(int)(c[0]),(int)(c[1]),(int)(c[2]),c[3],c[4],cluster_pts_indices[min_idx]+1,ds])       
    df=pd.DataFrame(List, columns  =['BCode','TUsers','WLoad','Lat','Long','SCode','Distance'])     
    df.to_csv ('BaseData/Data ('+file+'_List).csv', index=None, header = True) 
    return k,df
################################################################################################################
################################################################################################################
def Random(df,df2,k,file):
    df =BTS_Server_Di_Wl(df,df2,random.sample(range(0, len(df2.index)), k) ) 
    df.to_csv ('BaseData/Data ('+file+'_List).csv', index=None, header = True)
    return k,df
################################################################################################################
################################################################################################################
def TopK(df,df2,k,file):
    df =BTS_Server_Di_Wl(df,df2,list(df.iloc[:, : k].columns.values) )
    df.to_csv ('BaseData/Data ('+file+'_List).csv', index=None, header = True)
    return k,df
################################################################################################################
################################################################################################################

